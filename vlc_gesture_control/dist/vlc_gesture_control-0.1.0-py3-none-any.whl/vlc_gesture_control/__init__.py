"""
VLC Gesture Control - Control VLC media player using hand gestures
"""

__version__ = "0.1.0"
__author__ = "VLC Gesture Control Contributors"
__license__ = "MIT" 