"""
Tests for VLC Gesture Control
""" 