"""
Backward compatibility setup.py file.
Modern Python packaging uses pyproject.toml, but this file is provided for compatibility.
"""

from setuptools import setup

if __name__ == "__main__":
    setup() 